import './TagView.css';
import React, { useState } from 'react';
import PropTypes from 'prop-types';

const TagView = ({ tag, onUpdate, onAddChild }) => {
  const [collapsed, setCollapsed] = useState(false);
  const [data, setData] = useState(tag.data || '');

  const toggleCollapse = () => {
    setCollapsed(!collapsed);
  };

  const handleDataChange = (event) => {
    const newData = event.target.value;
    setData(newData);

    const updatedTag = { ...tag, data: newData };
    onUpdate(tag, updatedTag);
  };

  const handleAddChild = () => {
    onAddChild(tag);
  };

  return (
    <div className="tag">
      <div className="tag-header">
        <div className="tag-header-row">
          <button onClick={toggleCollapse}>
            {collapsed ? '>' : 'v'}
          </button>
          <div className="tag-name">{tag.name}</div>
          <button className='add-child-button' onClick={handleAddChild}>Add Child</button>
        </div>
      </div>
      {!collapsed && (
        
        <div className="tag-data">
          {tag.data ? (
            <input
              type="text"
              
              value={data}
              onChange={handleDataChange}
                
            />
            
          ) : null }
        </div>
        
        
      )}
       
      {!collapsed && (
        <div className="tag-children">
          {tag.children &&
            tag.children.map((child, index) => (
              <TagView
                key={index}
                tag={child}
                onUpdate={onUpdate}
                onAddChild={onAddChild}
              />
            ))}
        </div>
      )}
    </div>
  );
};

TagView.propTypes = {
  tag: PropTypes.shape({
    name: PropTypes.string.isRequired,
    data: PropTypes.string,
    children: PropTypes.arrayOf(PropTypes.object),
  }).isRequired,
  onUpdate: PropTypes.func.isRequired,
  onAddChild: PropTypes.func.isRequired,
};

export default TagView;
